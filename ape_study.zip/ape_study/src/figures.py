"""
figures.py  –  Paper Figures Generated from Real Data
======================================================
Generates Figs 1–5 exactly matching the paper.
Input: real results list from experiment.py
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path
from src.prompts import STRATEGY_LABELS, STRATEGIES

# ── Color palette ─────────────────────────────────────────────────────────────
C = {
    "baseline":   "#4A5568",
    "constraint": "#2B6CB0",
    "cot":        "#276749",
    "cove":       "#B7791F",
    "ape":        "#C53030",
    "gpt4o":      "#1A56DB",
    "gpt35":      "#0E9F6E",
    "llama":      "#E3A008",
    "mistral":    "#9061F9",
}

plt.rcParams.update({
    "font.family": "DejaVu Serif",
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 200, "savefig.dpi": 300,
})


def _m(results, **filters):
    """Compute HR%, Acc%, Faith% for a filtered subset."""
    grp = [r for r in results if all(r.get(k) == v for k, v in filters.items())]
    n = len(grp)
    if n == 0:
        return {"hr": 0, "acc": 0, "faith": 0, "lat": 0, "n": 0}
    return {
        "hr":    sum(r["is_hallucinated"]    for r in grp) / n * 100,
        "acc":   sum(r["is_accurate"]        for r in grp) / n * 100,
        "faith": sum(r["faithfulness_score"] for r in grp) / n * 100,
        "lat":   sum(r.get("latency_ms", 0)  for r in grp) / n / 1000,
        "n": n,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Fig 1: Per-Model Hallucination Rate  (Table III equivalent)
# ─────────────────────────────────────────────────────────────────────────────
def fig1_per_model(results, out_dir: Path):
    models  = sorted(set(r["model"] for r in results))
    x       = np.arange(len(models))
    width   = 0.75 / len(STRATEGIES)
    fig, ax = plt.subplots(figsize=(10, 5))

    for i, s in enumerate(STRATEGIES):
        hrs    = [_m(results, model=m, strategy=s)["hr"] for m in models]
        offset = (i - len(STRATEGIES)/2 + 0.5) * width
        bars   = ax.bar(x + offset, hrs, width * 0.92,
                        label=STRATEGY_LABELS[s], color=C[s], alpha=0.88,
                        edgecolor="white", linewidth=0.5)

    ax.set_xticks(x)
    ax.set_xticklabels([m.split(":")[0][:22] for m in models], rotation=10, ha="right")
    ax.set_ylabel("Hallucination Rate (%)")
    ax.set_title("Fig 1: Hallucination Rate by Model and Prompt Strategy")
    ax.legend(fontsize=8, ncol=3, frameon=False)
    ax.set_ylim(0, 105)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))
    plt.tight_layout()
    path = out_dir / "fig1_per_model_hr.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Fig 2: Overall HR by Strategy  (Table II visual)
# ─────────────────────────────────────────────────────────────────────────────
def fig2_overall_strategy(results, out_dir: Path):
    labels  = [STRATEGY_LABELS[s] for s in STRATEGIES]
    hrs     = [_m(results, strategy=s)["hr"]  for s in STRATEGIES]
    accs    = [_m(results, strategy=s)["acc"] for s in STRATEGIES]
    faiths  = [_m(results, strategy=s)["faith"] for s in STRATEGIES]

    x     = np.arange(len(STRATEGIES))
    w     = 0.25
    fig, ax = plt.subplots(figsize=(10, 5))

    b1 = ax.bar(x - w,   hrs,    w, label="Hallucination Rate (%)",  color="#C53030", alpha=0.85)
    b2 = ax.bar(x,        accs,   w, label="Accuracy (%)",            color="#2B6CB0", alpha=0.85)
    b3 = ax.bar(x + w,   faiths, w, label="Faithfulness (%)",         color="#276749", alpha=0.85)

    for bars in [b1, b2, b3]:
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h + 0.5,
                    f"{h:.1f}", ha="center", va="bottom", fontsize=7)

    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=12, ha="right")
    ax.set_ylabel("Score (%)")
    ax.set_title("Fig 2: Overall Results by Prompt Strategy (HR, Accuracy, Faithfulness)")
    ax.legend(fontsize=9, frameon=False)
    ax.set_ylim(0, 110)
    plt.tight_layout()
    path = out_dir / "fig2_overall_strategy.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Fig 3: Domain-Specific  Baseline vs APE  (Table IV visual)
# ─────────────────────────────────────────────────────────────────────────────
def fig3_domain_breakdown(results, out_dir: Path):
    domains = sorted(set(r["domain"] for r in results))
    base_hr = [_m(results, domain=d, strategy="baseline")["hr"] for d in domains]
    ape_hr  = [_m(results, domain=d, strategy="ape")["hr"]      for d in domains]

    x     = np.arange(len(domains))
    w     = 0.35
    fig, ax = plt.subplots(figsize=(9, 4.5))
    b1 = ax.barh(x + w/2, base_hr, w, label="Baseline", color="#718096", alpha=0.85)
    b2 = ax.barh(x - w/2, ape_hr,  w, label="APE (C+R+V)", color=C["ape"], alpha=0.85)

    for bar, val in zip(b1, base_hr):
        ax.text(val + 0.4, bar.get_y() + bar.get_height()/2,
                f"{val:.1f}%", va="center", fontsize=9)
    for bar, val in zip(b2, ape_hr):
        ax.text(val + 0.4, bar.get_y() + bar.get_height()/2,
                f"{val:.1f}%", va="center", fontsize=9)

    # Reduction labels
    for i, (d, b, a) in enumerate(zip(domains, base_hr, ape_hr)):
        red = (b - a) / b * 100 if b > 0 else 0
        ax.text(max(b, a) + 3, i, f"↓{red:.1f}%", va="center", fontsize=8,
                color=C["ape"], fontweight="bold")

    ax.set_yticks(x); ax.set_yticklabels([d.capitalize() for d in domains], fontsize=10)
    ax.set_xlabel("Hallucination Rate (%)")
    ax.set_title("Fig 3: Domain-Specific Hallucination Rate — Baseline vs. APE")
    ax.legend(fontsize=9, frameon=False)
    plt.tight_layout()
    path = out_dir / "fig3_domain_breakdown.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Fig 4: Ablation Line Chart  (Table V visual)
# ─────────────────────────────────────────────────────────────────────────────
def fig4_ablation_line(results, out_dir: Path):
    labels = [STRATEGY_LABELS[s] for s in STRATEGIES]
    hrs    = [_m(results, strategy=s)["hr"]  for s in STRATEGIES]
    accs   = [_m(results, strategy=s)["acc"] for s in STRATEGIES]

    fig, ax1 = plt.subplots(figsize=(9, 4.5))
    ax2 = ax1.twinx()

    l1, = ax1.plot(labels, hrs,  "o-", color=C["ape"],  linewidth=2.2,
                   markersize=9, markerfacecolor="white", markeredgewidth=2.2,
                   label="Hallucination Rate (%) ↓")
    l2, = ax2.plot(labels, accs, "s--", color=C["constraint"], linewidth=2.0,
                   markersize=8, markerfacecolor="white", markeredgewidth=2.0,
                   label="Accuracy (%) ↑")

    for lbl, hr, acc in zip(labels, hrs, accs):
        ax1.annotate(f"{hr:.1f}%", (lbl, hr),
                     textcoords="offset points", xytext=(0, 9), ha="center",
                     fontsize=9, color=C["ape"])
        ax2.annotate(f"{acc:.1f}%", (lbl, acc),
                     textcoords="offset points", xytext=(0, -14), ha="center",
                     fontsize=9, color=C["constraint"])

    ax1.fill_between(labels, hrs, alpha=0.07, color=C["ape"])
    ax1.set_ylabel("Hallucination Rate (%)", color=C["ape"])
    ax2.set_ylabel("Accuracy (%)", color=C["constraint"])
    ax1.set_title("Fig 4: Ablation — Progressive HR Reduction & Accuracy Gain")
    ax1.set_ylim(0, max(hrs) * 1.4 if hrs else 50)
    ax2.set_ylim(min(accs) * 0.85, 105)
    ax1.tick_params(axis="x", rotation=15)

    lines = [l1, l2]
    labels_leg = [l.get_label() for l in lines]
    ax1.legend(lines, labels_leg, fontsize=9, frameon=False)
    plt.tight_layout()
    path = out_dir / "fig4_ablation.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Fig 5: Latency vs Hallucination Rate Trade-off  (Table VI visual)
# ─────────────────────────────────────────────────────────────────────────────
def fig5_latency_tradeoff(results, out_dir: Path):
    fig, ax = plt.subplots(figsize=(8, 5))
    for s in STRATEGIES:
        m = _m(results, strategy=s)
        lat, hr = m["lat"], m["hr"]
        ax.scatter(lat, hr, s=220, color=C[s], zorder=5,
                   edgecolors="white", linewidths=1.8,
                   label=STRATEGY_LABELS[s])
        ax.annotate(STRATEGY_LABELS[s], (lat, hr),
                    textcoords="offset points", xytext=(7, 4), fontsize=8.5)

    ax.set_xlabel("Average Latency per Query (s)")
    ax.set_ylabel("Hallucination Rate (%)")
    ax.set_title("Fig 5: Latency vs. Hallucination Rate Trade-off (Measured)")
    # Arrow annotations
    ax.annotate("← Lower is better", xy=(0.05, 0.06), xycoords="axes fraction",
                fontsize=8.5, color="gray")
    ax.annotate("↓ Lower is better", xy=(0.01, 0.45), xycoords="axes fraction",
                fontsize=8.5, color="gray", rotation=90)
    ax.legend(fontsize=8, frameon=False)
    plt.tight_layout()
    path = out_dir / "fig5_latency_tradeoff.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Bonus: Error Taxonomy Pie Chart
# ─────────────────────────────────────────────────────────────────────────────
def fig6_error_taxonomy(summary: dict, out_dir: Path):
    tax    = summary.get("error_taxonomy", {})
    cats   = ["knowledge_gap", "reasoning_failure",
              "prompt_misinterpretation", "ambiguous_query"]
    labels_map = {
        "knowledge_gap":            "Knowledge Gap",
        "reasoning_failure":        "Reasoning Failure",
        "prompt_misinterpretation": "Prompt Misinterp.",
        "ambiguous_query":          "Ambiguous Query",
    }
    counts = [tax.get(c, {}).get("count", 0) for c in cats]
    total  = sum(counts)
    if total == 0:
        print("  ⚠ No hallucinated APE records to plot taxonomy.")
        return

    pcts   = [c / total * 100 for c in counts]
    colors = ["#2B6CB0", "#C53030", "#B7791F", "#276749"]
    fig, ax = plt.subplots(figsize=(7, 5))
    wedges, texts, autotexts = ax.pie(
        pcts, labels=[labels_map[c] for c in cats],
        colors=colors, autopct="%1.1f%%",
        startangle=140, pctdistance=0.8,
    )
    for t in autotexts:
        t.set_fontsize(9)
    ax.set_title(f"Fig 6: Residual Hallucination Taxonomy\n(APE condition, n={total})",
                 fontsize=11, fontweight="bold")
    plt.tight_layout()
    path = out_dir / "fig6_error_taxonomy.pdf"
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"  ✔ {path.name}")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Generate all figures at once
# ─────────────────────────────────────────────────────────────────────────────
def generate_all(results: list[dict], summary: dict, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    print("\n📊 Generating publication figures from real data...")
    fig1_per_model(results, out_dir)
    fig2_overall_strategy(results, out_dir)
    fig3_domain_breakdown(results, out_dir)
    fig4_ablation_line(results, out_dir)
    fig5_latency_tradeoff(results, out_dir)
    fig6_error_taxonomy(summary, out_dir)
    print(f"  All figures → {out_dir}/\n")
