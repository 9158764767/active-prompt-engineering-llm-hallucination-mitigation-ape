# APE Study — Complete Real Implementation
## Active Prompt Engineering for Hallucination Mitigation in LLMs

---

## ⚠️ What Was Hardcoded in the Paper (and What This Fixes)

Every number listed below was **hardcoded** in the previous LaTeX. This implementation **computes them all from real API calls**:

| Paper Location | Hardcoded Value | Real Source After Running |
|---|---|---|
| Abstract | "76.5% reduction" | `summary["by_strategy"]` → computed |
| Abstract | "2,400 queries" | actual count from `all_results.json` |
| Table II | All HR/Accuracy/Faithfulness % | LLM-judge evaluation of real responses |
| Table III | Per-model HR (GPT-4o 18.4%, etc.) | Real calls per model |
| Table IV | Domain HR (Finance 82.8% reduction, etc.) | Real calls per domain |
| Table V | Ablation (C+R+V = 8.0%) | Real calls per strategy combo |
| Table VI | Latency (APE = 1.8s, RAG = 4.1s) | `latency_ms` measured per call |
| Table VII | Cohen's κ = 0.81 | Computed from human vs auto labels |
| §VIII-D | "Super-additive" claim | `check_super_additive()` function |
| §IX | McNemar p < 0.001 | `mcnemar_test()` function |
| Fig 1 | Per-model bar chart | `fig1_per_model()` from real data |
| Fig 2 | Domain breakdown | `fig3_domain_breakdown()` from real data |
| Error taxonomy | 38%/27%/21%/14% split | Real judge `error_category` field |

---

## Project Structure

```
ape_study/
├── run_all.py              ← SINGLE ENTRY POINT — run this
├── verify_provenance.py    ← Reviewers run this
├── src/
│   ├── dataset.py          ← 60 verified QA pairs (4 domains, cited sources)
│   ├── prompts.py          ← 5 strategies verbatim from Appendix A
│   ├── caller.py           ← Real API: Anthropic / OpenAI / Ollama
│   ├── metrics.py          ← McNemar, Cohen's κ, all metric functions
│   ├── figures.py          ← 6 publication PDFs from real data
│   └── latex_writer.py     ← Rewrites paper tables with real numbers
├── logs/
│   └── raw_calls/          ← ONE JSON PER API CALL ← your proof
└── results/
    ├── all_results.json    ← Every record
    ├── summary.json        ← All metrics
    ├── real_tables.tex     ← LaTeX tables with real numbers
    └── figures/            ← 6 PDF figures
```

---

## Setup

```bash
pip install anthropic openai scipy scikit-learn matplotlib numpy tqdm
```

---

## Running (pick ONE option)

### Option A — Anthropic/Claude (recommended)
```bash
export ANTHROPIC_API_KEY=sk-ant-...
python run_all.py --model claude-sonnet-4-20250514
```

### Option B — OpenAI
```bash
export OPENAI_API_KEY=sk-...
python run_all.py --model gpt-4o
# Or multi-model:
python run_all.py --model gpt-4o gpt-3.5-turbo
```

### Option C — Ollama (FREE, local, no API key)
```bash
# Install: https://ollama.ai
ollama pull llama3:8b      # fast, good for testing
ollama pull llama3:70b     # full paper quality
ollama pull mistral:7b
python run_all.py --model llama3:8b
```

### Full paper experiment (4 models)
```bash
python run_all.py \
    --model gpt-4o gpt-3.5-turbo llama3:70b mistral:7b \
    --domains all \
    --max-per-domain 15
```

### Quick smoke test (5 queries × 5 strategies = 25 calls)
```bash
python run_all.py --model claude-sonnet-4-20250514 \
    --domains general --max-per-domain 5
```

---

## What Gets Generated

| Output | Contents | Used For |
|--------|----------|----------|
| `logs/raw_calls/<uuid>.json` | Full call record per API call | **Proof of execution** |
| `logs/run_<ts>.jsonl` | Append-only run log | Crash recovery |
| `results/all_results.json` | All 300 records (60q×5strat) | Statistical analysis |
| `results/summary.json` | All metrics tables | Paper numbers |
| `results/real_tables.tex` | Ready-to-paste LaTeX | Replace hardcoded tables |
| `figures/fig1_per_model_hr.pdf` | Fig 1 | Paper Fig 1 |
| `figures/fig2_overall_strategy.pdf` | Fig 2 | Paper Fig 2 |
| `figures/fig3_domain_breakdown.pdf` | Fig 3 | Paper Fig 3 |
| `figures/fig4_ablation.pdf` | Fig 4 | Paper Fig 4 |
| `figures/fig5_latency_tradeoff.pdf` | Fig 5 | Paper Fig 5 |
| `figures/fig6_error_taxonomy.pdf` | Error pie chart | Paper Fig 6 |

---

## Reviewer Verification

```bash
python verify_provenance.py
```

Each `logs/raw_calls/<uuid>.json` contains:
```json
{
  "call_id":         "550e8400-e29b-41d4-a716-446655440000",
  "timestamp_utc":   "2024-01-15T14:30:22.411Z",
  "model":           "gpt-4o",
  "prompt_messages": [...],
  "response_text":   "Apple's net income for FY2022 was $99.803 billion...",
  "input_tokens":    347,
  "output_tokens":   183,
  "latency_ms":      1842
}
```

**Token counts are the gold-standard proof** — they only exist if the API was genuinely called.

---

## Dataset

60 questions, all with publicly verifiable ground-truth answers and cited sources:

| Domain | Questions | Examples |
|--------|-----------|---------|
| General | 15 (5E/5M/5H) | Speed of light, WWII dates, thermodynamics |
| Finance | 15 (5E/5M/5H) | Apple FY2022 earnings, CAPM formula, Basel III |
| Healthcare | 15 (5E/5M/5H) | Type 2 diabetes treatment, Sepsis-3 criteria |
| Legal | 15 (5E/5M/5H) | Miranda v. Arizona, Marbury v. Madison, GDPR |

All ground-truth answers include the citation source (textbook, SEC filing, court case, WHO guideline).

---

## Human Evaluation (Cohen's κ)

The paper reports Cohen's κ = 0.81. To reproduce this:

1. Export 30 random records: `python export_for_human_eval.py`
2. Have annotators fill `human_eval_template.csv`
3. Run: `python compute_kappa.py human_eval_results.csv`

The `cohens_kappa()` function in `src/metrics.py` computes this from any two label lists.
